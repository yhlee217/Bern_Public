# 1.2.05 Chunker 고급 실습

## 실습 파일
- `01_rule_based_chunker.py` - 문장/문단 기준 분할

## 실행
```bash
python 01_rule_based_chunker.py
```

## 학습 내용
- 정규식 패턴 매칭
- 문장 경계 인식
- 자연스러운 청크 생성
