# 1.2.06 Metadata 실습

## 실습 파일
- `01_metadata_creation.py` - 메타데이터 생성 및 관리

## 실행
```bash
python 01_metadata_creation.py
```

## 학습 내용
- 문서 메타데이터 구조
- 자동 메타데이터 생성
- 품질 점수 계산
