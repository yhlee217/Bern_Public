# 1.2.08 Vector Search 실습

## 실습 파일
- `01_cosine_similarity.py` - 코사인 유사도 기반 검색

## 실행
```bash
python 01_cosine_similarity.py
```

## 학습 내용
- 코사인 유사도 계산
- 벡터 검색 알고리즘
- Top-K 결과 반환
